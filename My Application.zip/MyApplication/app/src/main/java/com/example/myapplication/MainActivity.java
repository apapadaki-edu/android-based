package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;


public class MainActivity extends AppCompatActivity{
    private EditText contactField;
    private EditText bodyField;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        contactField = (EditText)findViewById(R.id.contact_edit_text);
        bodyField = (EditText) findViewById(R.id.body_edit_text);

        Button sendEmailButton = (Button) findViewById(R.id.button_email);
        Button sendSMSButton = (Button) findViewById(R.id.button_sms);
        Button clearBodyButton = (Button) findViewById(R.id.button_clear);

        sendEmailButton.setOnClickListener(this::sendEmail);
        sendSMSButton.setOnClickListener(this::sendSMS);
    }

    public void sendSMS(View view){
        String contact = contactField.getText().toString();
        try{
            if (contact.trim().length() > 0 && contact.matches("(\\+\\d{2} )?\\d{10}")){
                Intent sendSMS = new Intent(Intent.ACTION_SENDTO); //ACTION_VIEW
                sendSMS.setData(Uri.parse("smsto:" + contact));
                sendSMS.putExtra("sms_body", bodyField.getText().toString());
                startActivity(sendSMS);
            }else {
                Toast.makeText(getApplicationContext(), getString(R.string.invalid_phone_number_toast), Toast.LENGTH_LONG).show();
            }
        } catch(Exception e){
            Toast.makeText(super.getBaseContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    public void sendEmail(View view){
        String address = contactField.getText().toString();
        try {
            if(address.trim().length() > 0 && address.matches("^\\w+([\\.-]?\\w+)*@\\w+([\\.-]?\\w+)*(\\.\\w{2,3})+$")){
                Intent sendEmail = new Intent(Intent.ACTION_SEND);
                sendEmail.putExtra(Intent.EXTRA_EMAIL, new String[] {address});
                sendEmail.putExtra(Intent.EXTRA_TEXT,  bodyField.getText().toString());

                // to open apps that can handle emails
                sendEmail.setType("message/rfc822");

                startActivity(Intent.createChooser(sendEmail, getString(R.string.email_app_chooser_prompt)));

            }else {
                Toast.makeText(getApplicationContext(), getString(R.string.invalid_email_toast), Toast.LENGTH_LONG).show();
            }
        }catch(Exception e){
            Toast.makeText(getApplicationContext(), e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }
}
